=== Plugin Name ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: https://github.com/piclaunch
Tags: ameliabooking, Amelia Booking
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

We  all love Amelia Booking, this plugin gives the space to use js hooks given by Amelia Booking to wirite your code for Booking page. 
Remove colons (:) from the booking from's label. Enjoy this work and share your feedback.

== Description ==

We  all love Amelia Booking, this plugin gives the space to use js hooks given by Amelia Booking to wirite your code for Booking page. 
Remove colons (:) from the booking from's label. Enjoy this work and share your feedback.

Dependent on Pluing : [Ameliabooking](https://wordpress.org/plugins/ameliabooking/)
Have question or issue : [Raise an issue on github](https://github.com/piclaunch/Lazy_Amelia/issues)

Key Feature:

*   Write your javascript code for booking page 
*   Write your javascript code for afterbooking loaded page.
*   Ability to write your custom JS on the page.
*   Setting to remove Colons (:) from the form's label 

**Support:**
* Write us at piclaunch@gmail.com with subject : "Lazy Amelia: <Open Text>"  or 
* [Raise an issue on github](https://github.com/piclaunch/Lazy_Amelia/issues) 

    
== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `lazy_amelia.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php do_action('plugin_name_hook'); ?>` in your templates

== Frequently Asked Questions ==

= How can I remove colons from label of the Amelia booking froms =

Go to settings -> "Lazy Amelia" -> Look for More "Quick Function" 
Check the setting "No Colons (:) after Label"

= Any question wite us piclaunch@gamil.com =
Find out more at http://www.piclaunch.com

Follow us on Twitter: [@piclaunch](https://twitter.com/piclaunch)

== Screenshots ==

1. Colons (:) Removed after activating the setting.
2. Settings to enable to remove colons
3. Full Setting 



== Changelog ==

= 1.0 =
* A change since the previous version.
* Another change.

= 0.5 =
* List versions from most recent at top to oldest at bottom.

== Upgrade Notice ==


